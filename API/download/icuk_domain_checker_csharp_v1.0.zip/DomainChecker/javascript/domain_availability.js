﻿jQuery(document).ready(function () {

    // When page loads, if a domain name was passed in the query string, start the search
    if (location.search != "") {
        doDomainNameSearch(event, 0, "doDomainNameSearch");
    }

    // Show domains that are selected
    resetImages();
});

// Reset result images.
function resetImages() {

    jQuery("input[type=checkbox]").each(function () {
        var el = jQuery(this);
        var name = el.attr("name").replace("select_", "");
        var display = "";
        if (!el.prop("checked")) {
            display = "none";
        }

        jQuery("a[href=#" + name + "]").css("display", display);
        jQuery("#" + name).css("display", display);
        jQuery("#sub_" + name).css("display", display);
    });
}


// Clear results panel.
function clearResultsPane() {

    document.getElementById("divResults").style.display = "none";

    for (var i = document.getElementById("divResultsBad").childNodes.length - 1; i >= 0; i--) {
        document.getElementById("divResultsBad").removeChild(document.getElementById("divResultsBad").childNodes[i])
    }

    document.getElementById("divResultsOk").style.display = "none";

}

// Submit form 
function processResult(buttonId, text, opt) {

    // Check if user wishes to submit form
    if (buttonId == "ok") {

        // Retrieve the parent form from the element which fired event
        elForm = document.getElementById(opt.animEl).form;
        elForm.submit();

    }
}

// Searches for domain availability for all extensions.
function doDomainNameSearch() {

    res = jQuery("#divDomainNameResults");

    // Strip domain of spaces and set to lower case      
    var ds = jQuery(".domain-search").val().toLowerCase().replace(/ /g, "");
    jQuery(".domain-search").val(ds);

    if (ds == "") {
        return;
    }

    var foundSpecific = false;
    var specificExt = "";

    // Remove any domain extensions added.
    try {

        if (ds.indexOf('.') != -1) {
            specificExt = ds.substring(ds.indexOf('.'));
            ds = ds.split('.')[0];
            jQuery(".domain-search").val(ds);
        }
    }
    catch (err) { }

    // Loop through each table row
    res.find("tr").each(function () {
        var row = jQuery(this);

        // Only process domain name rows - skip headers
        if (row.parent().prop("nodeName").toLowerCase() != "thead") {
            var cat = row.parent().attr("id").substring(5);
            var tld = (row.attr("name").substring(2).replace(/_/g, "."));

            // If looking for a specific extension. Skip ones we don't require
            if (specificExt == "") {

                // If category not selected then skip
                if (!jQuery("[name=select_" + cat + "]").prop("checked")) {
                    return true;
                }
            }
            else {
                if (specificExt == tld) {
                    foundSpecific = true;
                }
                else {
                    return true;
                }
            }
            var domain = ds + tld;

            row.find("td:first").html(domain);

            // Reset current domain progress display 
            ResetProgress(row)

            // Display Loading 
            row.find("div:nth-child(1)").css("display", "");

            // Do search , search for first immediately - defer all subsequent
            SearchOne(domain, row.attr("name"));

        }

    });

    // Specific
    if (specificExt != "" && !foundSpecific) {
        doDomainNameSearch();
    }

}

// Searches for a specific domain name availability.
function SearchOne(dn, eName) {

    jQuery.ajax({
        url: '/index.aspx?action=domain-name-check',
        type: 'POST',
        data: {
            domainName: dn,
            element: eName
        },
        dataType: 'json',
        success: function (result) {
            // Report the outcome 
            DomainNameResult(result);
        },
        failure: function (result)
        {
            TimedOut(eName);
        }
    });
}

// Display the results.
function DomainNameResult(result) {

    // Display outcome 
    el = result.element;
    av = result.availability;

    var row = jQuery("tr[name=" + el + "]");

    ResetProgress(row)

    if (av == 'true') {
           
        // Available
        row.find("div:nth-child(2)").css("display", "");
    }
    else {
        if (av == 'false') {
            // Unavailable
            row.find("div:nth-child(3)").css("display", "");
        }
        else {
            //Unknown
            row.find("div:nth-child(4)").css("display", "");
        }
    }
}

// Availability domain checker timedout.
function TimedOut(eName) {

    // If no result comes back then display timed out
    jQuery("#" + eName).find("div:nth-child(5)").css("display", "");  //TimedOutUnknown

}

// Reset domain availability search progress.
function ResetProgress(res) {

    // Default display - all status turned off 
    res.find("div").css("display", "none");  //Loading
}

// Display sub categories
function toggleCat(event, name) {

    var cat = jQuery(event);
    var parent = cat.parent().parent();
    var display = "";
    if (!cat.prop("checked")) {
        display = "none";
    }
    
    if (!jQuery(event).parent().hasClass('sub-category-heading')) {
        parent.children('.sub-category-heading').each(function () {
            jQuery(this).css("display", display);
            jQuery(this).children("input").prop("checked", (display == ""));
        });
    }

    toggleTabs(name, display);

    resetImages();
}

// Display tab and content
function toggleTabs(name, display) {
    jQuery("a[href=#" + name + "]").css("display", display);
    jQuery("#" + name).css("display", display);
}

// Display sub category content
function toggleSubCat(event, name) {
    var cat = jQuery(event);
    var parent = cat.parent();
    var display = "";
    if (!cat.prop("checked")) {
        display = "none";
    }
    jQuery("#sub_" + name).css("display", display);
}

// Show domain information dialog
function showDomainInfomation(content, title) {

    var dialog = $('#domain-dialog');
    dialog.find('.modal-title').html(title);
    dialog.find('.modal-body').html(content);
    dialog.modal('show');

}