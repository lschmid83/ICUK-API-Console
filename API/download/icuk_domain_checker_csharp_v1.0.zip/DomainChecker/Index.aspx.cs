﻿using IcukApiCSharpSdk;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DomainChecker {

    /// <summary>
    /// Example page which sends request using the C# SDK to check for domain availability.
    /// </summary>
    public partial class index : System.Web.UI.Page {

        /// <summary>
        /// Event which is triggered when the page loads.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">Event arguments.</param>
        protected void Page_Load(object sender, EventArgs e) {

            // Handle page actions
            string pageAction = HttpContext.Current.Request.QueryString["action"];
            if (pageAction == "domain-name-check") {

                string domainName = (String)HttpContext.Current.Request.Params.Get("domainName");
                string htmlElement = (String)HttpContext.Current.Request.Params.Get("element");
                Response.Write(DomainNameCheck(domainName, htmlElement));
                return;
            }
            Main();
        }
        
        /// <summary>
        /// Sends API request for domain availability using the C# SDK.
        /// </summary>
        /// <param name="domainName">Domain name.</param>
        /// <param name="element">Element to update with results.</param>
        /// <returns>API response.</returns>
        public string DomainNameCheck(string domainName, string element) {

            IcukApiClient api = new IcukApiClient {
                Username = "<username>",
                Key = "<key>",
                Encryption = "SHA-512"
            };

            IcukApiRequest req = new IcukApiRequest {
                Url = "/domain/availability/" + domainName,
                Method = "GET"
            };

            string availability;
            IcukApiResponse res = api.Send(req);
            if (res.Success) {
                JObject json = JsonConvert.DeserializeObject<JObject>(res.Response);
                availability = json.GetValue("available").ToString().ToLower();
            }
            else {
                availability = "unknown";
            }
            
            JObject result = new JObject();
            result.Add("domainname", domainName);
            result.Add("element", element);
            result.Add("availability", availability);

            return result.ToString();

        }
        
        /// <summary>
        /// Retrieve the domain categories.
        /// </summary>
        /// <returns>Array of domain_ext_category objects.</returns>
        private domain_ext_category[] RetrieveDomainCategories() {

            List<domain_ext_category> domainCategories = new List<domain_ext_category>();

            IcukApiCSharpSdk.IcukApiRequest request = new IcukApiCSharpSdk.IcukApiRequest() {
                Url = "/domain/domain_detail/",
                Method = "GET"
            };

            IcukApiCSharpSdk.IcukApiClient api = new IcukApiCSharpSdk.IcukApiClient() {
                Username = "<username>",
                Key = "<key>"
            };

            // Send request and return response
            IcukApiCSharpSdk.IcukApiResponse response = api.Send(request);

            domain_detail_results results;
            if (response.Success) {
                results = (domain_detail_results)JsonConvert.DeserializeObject(response.Response,
                    typeof(domain_detail_results),
                    new JsonSerializerSettings { DefaultValueHandling = DefaultValueHandling.Ignore });
            }
            else {
                throw new Exception("There was an error contacting the API.");
            }

            return results.domain_details.ToArray();
        }

        /// <summary>
        /// Main webpage template.
        /// </summary>
        private void Main() {

            StringBuilder html = new StringBuilder();

            // Head
            html.Append(@"
<!DOCTYPE html>
<html lang='en'>
<head>	
	<title>Domain Availability Checker</title>
	<meta charset='utf-8'>
	<meta name='viewport' content='width=device-width, initial-scale=1.0'>	
	<meta name='description' content='Domain name checker allowing you to search for availability and prices of gLTDs.'>
	<meta name='keywords' content='domain, checker, availability, gltd'>
	<meta http-equiv='content-type' content='text/html; charset=iso-8859-1'>	
	<link href='/css/bootstrap.css' rel='stylesheet' />
	<link href='/css/style.css' rel='stylesheet' />
	<script src='/javascript/jquery.js' type='text/javascript'></script>
	<script src='/javascript/bootstrap.js' type='text/javascript'></script>
	<script src='/javascript/domain_availability.js' type='text/javascript'></script>
</head>");


            // Header
            html.Append(@"
<body>

	<div class='header'>
		<div class='header-center'>
			<div class='header-title'>
				<h1>Domain Availabilty Checker</h1>
				<p>Search for your own domain name</p>
			</div>
			<div class='header-signup pull-right'>
				<a href='/signup.aspx' class='btn btn-mini btn-success btn-signup btn-custom-lighten' type='button'>SIGNUP ONLINE</a>
			</div>						
		</div>
  	</div>");


            // Content
            html.Append(@"
    <div class='content'>	
    
        <div class='content-header'>
			<h1>Search for a Domain Name</h1>
			<h2>Enter a keyword or name to search for available domains from around the world</h2>
        </div>");

            // Domain search form
            html.Append(@"	
		<form class='content-form' method='get' action='' id='form-domain' role='form' name='form-domain'>
			
			<div class='domain-search-container'>
                <input class='domain-search form-control' type='text' value='" + Request.QueryString["domain"] + @"' placeholder='Keyword or Name'>
				<button type='button' class='btn btn-success btn-search' onclick='doDomainNameSearch(); return false;''><span class='glyphicon glyphicon-search'></span> Search</button>
			</div>
			
			<div class='domain-description'>
				<p>We check all variants for you, so there's no need to include an extension such as <em>.com</em> or <em>.co.uk</em>.</p>
			</div>");
            

            // Retieve categories
            domain_ext_category[] cats = RetrieveDomainCategories();

            StringBuilder headingHtml = new StringBuilder();
            StringBuilder bodyHtml = new StringBuilder();
            StringBuilder selectionHtml = new StringBuilder();
            Int32 count = 0;
            string mainCategoryId = "", subCategoryId = "";

            foreach (domain_ext_category mainCategories in cats) {

                count++;
                String classString = "";
                String initialChecked = "";
                if (count == 1) {
                    classString = "active";
                    initialChecked = "checked='checked' ";
                };

                mainCategoryId = mainCategories.name.Replace(" ", "_");
                mainCategoryId = mainCategoryId.Replace("&", "");

                // Selection of domains
                selectionHtml.Append(@"
						<div class='domain-categories-container'>
                            <div class='checkbox'>
							    <input " + initialChecked + @" type='checkbox' onclick='toggleCat(this, """ + mainCategoryId + @""")' name='select_" + mainCategoryId + @"' value='1'>" + mainCategories.name + @"
                            </div>");
                
                foreach (domain_ext_category subCategories in mainCategories.categories) {

                    subCategoryId = subCategories.name.Replace(" ", "_");
                    subCategoryId = subCategoryId.Replace("&", "");

                    selectionHtml.Append(@"
                            <div class='checkbox sub-category-heading'>
								<input " + initialChecked + @" type='checkbox' onclick='toggleCat(this, ""sub_" + mainCategoryId + "_" + subCategoryId + @""")' name='select_" + mainCategoryId + "_" + subCategoryId + @"' value='1'>" + subCategories.name + @"
							</div>");
                }

                selectionHtml.Append(@"
						</div>");

                // Heading tabs
                headingHtml.Append(@"
					<li class='" + classString + "' ><a href='#" + mainCategoryId + "' data-toggle='tab'>" + mainCategories.name + "</a></li>");

                // Contents of tabs
                bodyHtml.Append(@"
					<!-- TAB " + mainCategoryId + @"-->
					<div class='tab-pane " + classString + "' id='" + mainCategoryId + @"'>");

                // Add sub categories
                foreach (domain_ext_category subCategories in mainCategories.categories) {

                    subCategoryId = subCategories.name.Replace(" ", "_");
                    subCategoryId = subCategoryId.Replace("&", "");                   
                    
                    bodyHtml.Append("<div id='sub_" + mainCategoryId + "_" + subCategoryId + "'>");
                    bodyHtml.Append("<h3>" + subCategories.name + "</h3>");
                    bodyHtml.Append(DomainAvailabilityResults(mainCategoryId + "_" + subCategoryId, subCategories));
                    bodyHtml.Append("</div>");
                }

                bodyHtml.Append(DomainAvailabilityResults(mainCategoryId, mainCategories));

                bodyHtml.Append(@"
					</div>				
");
            }

            html.Append("<div class='domain-categories'>");

            html.Append("<div>" + selectionHtml.ToString() + "</div>");
            html.Append(@"

	        <div style='clear:both' class='tab-domain-categories'>
		        <div class='tabbable' style='margin-bottom: 18px;'>
			
			        <ul class='nav nav-tabs'>"
                            + headingHtml + @"
			        </ul>  
             
			        <div id='divDomainNameResults' class='tab-content' style='padding: 15px; border: 1px solid #ddd;'>"
                            + bodyHtml + @"
			        </div>
		        </div>
	        </div>
        </form>
	</div>
");
            // Domain information dialog
            html.Append(@"
    <div class='modal fade' id='domain-dialog' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true' style='overflow-y:auto'>
      <div class='modal-dialog'>
        <div class='modal-content'>
          <div class='modal-header'>
            <button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
            <h4 class='modal-title'></h4>
          </div>
          <div class='modal-body'></div>
          <div class='modal-footer'>
            <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
          </div>
        </div>
      </div>
    </div>
</body>
</html>");   
	
            HttpContext.Current.Response.Write(html.ToString());
        }

        /// <summary>
        /// Creates the domain availability results table for a domain category.
        /// </summary>
        /// <param name="categoryName">Domain category name.</param>
        /// <param name="category">domain_ext_cateogry object.</param>
        /// <returns>Domain availability results table.</returns>
        private StringBuilder DomainAvailabilityResults(String categoryName, domain_ext_category category) {

            StringBuilder bodyHtml = new StringBuilder();

            bodyHtml.Append(@"
						<table class='content-table table-curved table-hover' style='width:100%;'>
						<thead>
							<tr>
								<th style='width:60%'>&nbsp;Domain Name</th>
								<th style='width:10px'>&nbsp;</th>								
								<th class='centered' style='width:25%'>&nbsp;Availability</th>
								<th class='centered' style='width:15%'>&nbsp;Frequency</th>
							</tr>
						</thead>

						<tbody id='tbody" + categoryName + @"'>
						");

            foreach (domain_information ext in category.extensions) {
                bodyHtml.Append(@"
						<!-- " + ext.extension + @" -->
						<tr name='id_" + ext.extension.Replace('.', '_') + @"'>
							<td  value='." + ext.extension + @"' >." + ext.extension + @"</td>
							<td><img src='/images/domain_checker_question.png' border='0' style='cursor:pointer;' class='domain-question' onclick='showDomainInfomation("" <div class=domain-dialog-text>" + DomainInformation(ext) + @"</div>"",""." + ext.extension + @""");' /></td>
							<td class='centered'>
								<div style='display:none'><img id='imgloading' alt='checking domain status' src='/images/domain_checker_working.gif' class='domain-loading' /> Checking</div>
								<div style='display:none'><img id='imgavail' alt='this domain is available' src='/images/domain_checker_yes.gif' class='domain-status' /> Available</div>
								<div style='display:none'><img id='imgtaken' alt='this domain has been taken' src='/images/domain_checker_no.gif' class='domain-status' /> Taken</div>
								<div style='display:none'><img id='imgunknown' alt='we cannot, at the moment, determine the status of this domain' src='/images/domain_checker_unknown.png' class='domain-status' /> Unknown</div>
								<div style='display:none'><img id='imgtimedout' alt='this query timed out...' src='/images/domain_checker_timed_out.png' class='domain-status' /> Timed out...</div>
							</td>
							<td class='centered'>" + ext.period + @" Years</td>
						</tr>");
            }
            bodyHtml.Append(@"
						</tbody>
						</table>");

            return bodyHtml;
        }

        /// <summary>
        /// Creates domain information dialog text.
        /// </summary>
        /// <param name="domainInformation">domain_information object.</param>
        /// <returns>Domain information dialog text.</returns>
        private string DomainInformation(domain_information domainInformation) {
        
            StringBuilder html = new StringBuilder();

            if(!String.IsNullOrEmpty(domainInformation.name))
                html.Append("Name: " + domainInformation.name + "<br/>");
            
            if(domainInformation.period > 0)
                html.Append("Period: " + domainInformation.period + " years<br/>");
            
            if(domainInformation.max_period > 0)
                html.Append("Max period: " + domainInformation.max_period + " years<br/>");
            
            if(domainInformation.cancellation_period > 0)
                html.Append("Cancellation period: " + domainInformation.cancellation_period + " days<br/>");
            
            if(domainInformation.grace_period > 0)
                html.Append("Grace period: " + domainInformation.grace_period + " days<br/>");
            
            if(domainInformation.redemption_period > 0)
                html.Append("Redemption period: " + domainInformation.redemption_period + " days<br/>");
            
            if(!String.IsNullOrEmpty(domainInformation.dns_requirements))
                html.Append("DNS requirements: " + domainInformation.dns_requirements + "<br/>");
            
            if(!String.IsNullOrEmpty(domainInformation.transfers))
                html.Append("Transfer requirements: " + domainInformation.transfers + "<br/>");

            return html.ToString();

        }

        /// <summary>
        /// Result container for domain extensions and categories.
        /// </summary>
        public struct domain_detail_results {

            /// <summary>
            /// Array of domain_details_results structs.
            /// </summary>
            public List<domain_ext_category> domain_details { get; set; }

        }

        /// <summary>
        /// Represents domain extensions and categories.
        /// </summary>
        public struct domain_ext_category {

            /// <summary>
            /// Domain categories.
            /// </summary>
            public string name { get; set; }

            /// <summary>
            /// Domain extension information.
            /// </summary>
            public domain_information[] extensions { get; set; }

            /// <summary>
            /// Domain categories.
            /// </summary>
            public domain_ext_category[] categories { get; set; }

        }

        /// <summary>
        /// Represents domain extensions information.
        /// </summary>
        public struct domain_information {

            /// <summary>
            /// Domain extension.
            /// </summary>
            public string extension { get; set; }

            /// <summary>
            /// Domain name.
            /// </summary>
            public string name { get; set; }

            /// <summary>
            /// Domain price (£).
            /// </summary>
            public decimal price { get; set; }

            /// <summary>
            /// Domain period.
            /// </summary>
            public int period { get; set; }

            /// <summary>
            /// Max domain period.
            /// </summary>
            public int max_period { get; set; }

            /// <summary>
            /// DNS requirements.
            /// </summary>
            public string dns_requirements { get; set; }

            /// <summary>
            /// Cancellation period.
            /// </summary>
            public int cancellation_period { get; set; }

            /// <summary>
            /// Grace period.
            /// </summary>
            public int grace_period { get; set; }

            /// <summary>
            /// Redemption period.
            /// </summary>
            public int redemption_period { get; set; }

            /// <summary>
            /// Transfers.
            /// </summary>
            public string transfers { get; set; }

        }
    }
}