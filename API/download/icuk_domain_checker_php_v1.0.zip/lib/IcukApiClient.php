<?php

include 'IcukApiRequest.php';
include 'IcukApiResponse.php';

/**
 * ICUK API client.
 * @property $username
 * @property $key
 * @property $encryption
 */
class IcukApiClient {

	/**
	 * The username of the connecting user.
	 */
	public $username;

	/** 
	 * The user's supplied API key.
	 */
	public $key;

	/**
	 * The authentication method.
	 */
	public $encryption;
		
	/*
	 * Sends the request.
	 * @param IcukApiRequest object.
	 * @return IcukApiResponse object.
	 */
	function send($request) {

		// Initialize the cURL session with the request URL
		$request->url = 'https://api.interdns.co.uk' . $request->url;
		$ch = curl_init($request->url); 
		
		// Set request method
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $request->method);  
		curl_setopt($ch, CURLOPT_POSTFIELDS, $request->body);
		
		// Tell cURL to return the request data
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
		
		// Stop cURL from verifying the peer's certificate
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		
		// Get the path to the API method from the request URL
		$apiMethod = parse_url($request->url, PHP_URL_PATH);

		// Calculate the authentication hash
		if($this->encryption == 'SHA-512') {
			$encryption = 'SHA-512';
			$hash = hash('sha512', $apiMethod . $this->key);
		}
		else if($this->encryption == 'SHA-256') {
			$hash = hash('sha256', $apiMethod . $this->key); 
		}
		else if($this->encryption == 'MD5') {
			$hash = hash('md5', $apiMethod . $this->key); 
		}
	
		// Set the HTTP request authentication headers
		$headers = array(
			'User: ' . $this->username,
			'Hash: ' . $hash,
			'Method: ' . $this->encryption
		);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		// Initialize result
		$result = new IcukApiResponse();
				
		// Execute cURL on the session handle
		$response = curl_exec($ch);

		// Get status code and response
		$result->statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$result->response = $response;
		
		// API method not found
		if($response == false) {
			$result->success = false;
			$result->errorMessage = curl_error($ch);
		}
		// API has thrown an exception
		else if($result->statusCode >= 400) {
			$result->success = false;
			$exception = json_decode($result->response);
			$result->errorMessage = $exception->exception_message;
			$result->errorType = $exception->exception_type;	
		}
		// Request was successful
		else {
			$result->success = true;
		}
				
		// Close the cURL session
		curl_close($ch);	
		
		// Return the result
		return $result;
	}
}
?>