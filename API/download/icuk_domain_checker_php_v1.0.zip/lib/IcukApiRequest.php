<?php

/**
 * ICUK API request.
 * @property $url
 * @property $method
 * @property $body
 */
class IcukApiRequest {

	/**
	 * Method URL.
	 */
	public $url;

	/** 
	 * HTTP request method.
	 */
	public $method;

	/**
	 * Request body.
	 */
	public $body;
	
}
?>