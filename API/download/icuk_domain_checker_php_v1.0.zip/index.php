<?php
	include '/lib/IcukApiClient.php';

	// Handle page actions
	$action = isset($_GET["action"]) ? $_GET["action"] : "";
	if($action == 'domain-name-check') {
		$domainName = isset($_POST["domainName"]) ? $_POST["domainName"] : "";
		$htmlElement = isset($_POST["element"]) ? $_POST["element"] : "";
		echo domainNameCheck($domainName, $htmlElement);
		return;
	}
	else
		main();
		
	/**
     * Sends API request for domain availability using the PHP SDK.
	 * @param domainName Domain name.
	 * @param element Element to update with results.
	 */
	function domainNameCheck($domainName, $element) {

		$result = '';

		$client = new IcukApiClient();
		$client->username = "<username>";
		$client->key = "<key>";
		$client->encryption = "SHA-512";

		$req = new IcukApiRequest();
		$req->url = "/domain/availability/" . $domainName;
		$req->method = "GET";
		
		$res = $client->send($req);
		$availability = 'unknown';
		if ($res->success) {
			$obj = json_decode($res->response);
			$availability =($obj->available) ? 'true' : 'false';
		}
		else {
			$availability = 'unknown';
		}
		
		$result = new stdClass();
		$result->domainname = $domainName;
		$result->element = $element;
		$result->availability = $availability;
						   
		return json_encode($result);
	}  	
	
	/**
	 * Sends API request for domain information using the PHP SDK.
	 * @return Array of domain_ext_category objects.
	 */
	function retrieveDomainCategories() {
	
		$client = new IcukApiClient();
		$client->username = "<username>";
		$client->key = "<key>";
		$client->encryption = "SHA-512";

		$req = new IcukApiRequest();
		$req->url = "/domain/domain_detail/";
		$req->method = "GET";
		
		$res = $client->send($req);
		if ($res->success) {
			$obj = json_decode($res->response);
		}
		else {
			throw new Exception('There was an error contacting the API.');
		}
		
		return $obj->domain_details;
	}
		
	/**
	 * Main webpage template.
	 */
    function main() {

        // Head
        $html = "
<!DOCTYPE html>
<html lang='en'>
<head>	
	<title>Domain Availability Checker</title>
	<meta charset='utf-8'>
	<meta name='viewport' content='width=device-width, initial-scale=1.0'>	
	<meta name='description' content='Domain name checker allowing you to search for availability and prices of gLTDs.'>
	<meta name='keywords' content='domain, checker, availability, gltd'>
	<meta http-equiv='content-type' content='text/html; charset=iso-8859-1'>	
	<link href='/css/bootstrap.css' rel='stylesheet' />
	<link href='/css/style.css' rel='stylesheet' />
	<script src='/javascript/jquery.js' type='text/javascript'></script>
	<script src='/javascript/bootstrap.js' type='text/javascript'></script>
	<script src='/javascript/domain_availability.js' type='text/javascript'></script>
</head>";

        // Header
        $html .= "
<body>

	<div class='header'>
		<div class='header-center'>
			<div class='header-title'>
				<h1>Domain Availabilty Checker</h1>
				<p>Search for your own domain name</p>
			</div>
			<div class='header-signup pull-right'>
				<a href='/signup.aspx' class='btn btn-mini btn-success btn-signup btn-custom-lighten' type='button'>SIGNUP ONLINE</a>
			</div>						
		</div>
  	</div>";

        // Content
        $html .="
	<div class='content'>	
    
        <div class='content-header'>
			<h1>Search for a Domain Name</h1>
			<h2>Enter a keyword or name to search for available domains from around the world</h2>
        </div>";
	
        // Retrieve domain categories
        $cats = retrieveDomainCategories();

		// Domain search form
        $html .= "
		<form class='content-form' method='get' action='' id='form-domain' role='form' name='form-domain'>
			
			<div class='domain-search-container'>
                <input class='domain-search form-control' type='text' value='' placeholder='Keyword or Name'>
				<button type='button' class='btn btn-success btn-search' onclick='doDomainNameSearch(); return false;''><span class='glyphicon glyphicon-search'></span> Search</button>
			</div>
			
			<div class='domain-description'>
				<p>We check all variants for you, so there's no need to include an extension such as <em>.com</em> or <em>.co.uk</em>.</p>
			</div>";

		$count = 0;
		$selectionHtml = '';
		$headingHtml = '';
		$bodyHtml = '';
		$classString = '';
		foreach ($cats as $mainCategories) {

			$count++;
			$classString = '';
			$initialChecked = '';			
			if($count == 1) {
				$classString = "active";
				$initialChecked = "checked='checked' ";
			}
			
			// Selection of domains
			$mainCategoryId = str_replace(' ', '_', $mainCategories->name);
			$subCategoryId = '';
			$selectionHtml .= "
			<div class='domain-categories-container'>
				<div class='checkbox'>
					<input " . $initialChecked . " type='checkbox' onclick='toggleCat(this, \"" . $mainCategoryId . "\")' name='select_" . $mainCategoryId . "' value='1'>" . $mainCategories->name;
			$selectionHtml .= "</div>";
			
	
			foreach ($mainCategories->categories as $subCategories) {
			
				$subCategoryId = str_replace(' ', '_', $subCategories->name);
				$selectionHtml .= "
				<div class='checkbox sub-category-heading'>
					<input " . $initialChecked . " type='checkbox' onclick='toggleCat(this, \"sub_" . $mainCategoryId . "_" . $subCategories->name . "\")' name='select_" . $mainCategoryId . "_" . $subCategoryId . "' value='1'>" . $subCategories->name;
				$selectionHtml .= "</div>";
				
			}

			$selectionHtml .= "
			</div>";
			
			// Heading tabs
			$headingHtml .= "
				<li class='" . $classString . "' ><a href='#" . $mainCategoryId . "' data-toggle='tab'>" . $mainCategories->name . "</a></li>";
			
			// Contents of tabs
			$bodyHtml .= "
				<!-- TAB " . $mainCategoryId . "-->
				<div class='tab-pane " . $classString . "' id='" . $mainCategoryId . "'>";
				
			// Add sub categories
			foreach ($mainCategories->categories as $subCategories) {
				$bodyHtml .= "<div id='sub_" . $mainCategoryId . "_" . $subCategoryId . "'>";
				$bodyHtml .= "<h3>" . $subCategories->name . "</h3>";
				$bodyHtml .= domainAvailabilityResults($mainCategoryId . "_" . $subCategoryId, $subCategories);
				$bodyHtml .= "</div>";
			}	

			$bodyHtml .= domainAvailabilityResults($mainCategoryId, $mainCategories);
			
			$bodyHtml .= "
				</div>";
		}
				
		$html .= "<div class='domain-categories'>";
		$html .= "<div>" . $selectionHtml . "</div>";
		
		$html .= "
	        <div style='clear:both' class='tab-domain-categories'>
		        <div class='tabbable' style='margin-bottom: 18px;'>
			
			        <ul class='nav nav-tabs'>"
                            . $headingHtml . "
			        </ul>  
             
			        <div id='divDomainNameResults' class='tab-content' style='padding: 15px; border: 1px solid #ddd;'>"
                            . $bodyHtml . "
			        </div>
		        </div>
	        </div>
        </form>
	</div>";		
		
		// Domain information dialog	
		$html .= "
	<div class='modal fade' id='domain-dialog' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true' style='overflow-y:auto'>
	  <div class='modal-dialog'>
		<div class='modal-content'>
		  <div class='modal-header'>
			<button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
			<h4 class='modal-title'></h4>
		  </div>
		  <div class='modal-body'></div>
		  <div class='modal-footer'>
			<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
		  </div>
		</div>
	  </div>
	</div>";   			
	
        $html .= "
</body>
</html>";

        echo $html;
    }
	
	/**
	 * Domain availability results.
	 * @categoryName Domain category name.
	 * @category domain_ext_category object.
	 * @result Domain availability results table.
	 */
	function domainAvailabilityResults($categoryName, $category) {
	
		$bodyHtml = "
					<table class='content-table table-curved table-hover' style='width:100%;'>
						<thead>
							<tr>
								<th style='width:60%'>&nbsp;Domain Name</th>
								<th style='width:10px'>&nbsp;</th>								
								<th class='centered' style='width:25%'>&nbsp;Availability</th>
								<th class='centered' style='width:15%'>&nbsp;Frequency</th>
							</tr>
						</thead>	
						<tbody id='tbody" . $categoryName . "'>";
		
		foreach ($category->extensions as $ext) {

			$bodyHtml .= "
						<!-- " . $ext->extension . " -->
						<tr name='id_" . str_replace('.', '_', $ext->extension) . "'>
							<td  value='." . $ext->extension . "' >." . $ext->extension . "</td>
							<td><img src='/images/domain_checker_question.png' border='0' style='cursor:pointer;' class='domain-question' onclick='showDomainInfomation(\"<div class=domain-dialog-text>" . getDomainInformation($ext) . "</div>\",\"." . $ext->extension . "\");' /></td>
							<td class='centered'>
								<div style='display:none'><img id='imgloading' alt='checking domain status' src='/images/domain_checker_working.gif' class='domain-loading' /> Checking</div>
								<div style='display:none'><img id='imgavail' alt='this domain is available' src='/images/domain_checker_yes.gif' class='domain-status' /> Available</div>
								<div style='display:none'><img id='imgtaken' alt='this domain has been taken' src='/images/domain_checker_no.gif' class='domain-status' /> Taken</div>
								<div style='display:none'><img id='imgunknown' alt='we cannot, at the moment, determine the status of this domain' src='/images/domain_checker_unknown.png' class='domain-status' /> Unknown</div>
								<div style='display:none'><img id='imgtimedout' alt='this query timed out...' src='/images/domain_checker_timed_out.png' class='domain-status' /> Timed out...</div>
							</td>
							<td class='centered'>" . $ext->period . " Years</td>
						</tr>";		
		}
		
		$bodyHtml .="
			</tbody>
			</table>";
		
		return $bodyHtml;	
	}
	
	/*
	 * Gets domain information dialog text.
	 * @param domain_information object
	 * @return Domain information dialog text.
	 */
	function getDomainInformation($domainInformation) {
	
		$html = "";
		if($domainInformation->name != "")
			$html .= "Name: " . $domainInformation->name . "<br/>";

		if($domainInformation->period > 0)
			$html .= "Period: " . $domainInformation->period . " years<br/>";
		
		if($domainInformation->max_period > 0)
			$html .= "Max period: " . $domainInformation->max_period . " years<br/>";
		
		if($domainInformation->cancellation_period > 0)
			$html .= "Cancellation period: " . $domainInformation->cancellation_period . " days<br/>";
		
		if($domainInformation->grace_period > 0)
			$html .= "Grace period: " . $domainInformation->grace_period . " days<br/>";
		
		if($domainInformation->redemption_period > 0)
			$html .= "Redemption period: " . $domainInformation->redemption_period . " days<br/>";
		
		if($domainInformation->dns_requirements != "")
			$html .= "DNS requirements: " . $domainInformation->dns_requirements . "<br/>";
		
		if($domainInformation->transfers != "")
			$html .= "Transfer requirements: " . $domainInformation->transfers . "<br/>";	
	
		return $html;
	}

?>