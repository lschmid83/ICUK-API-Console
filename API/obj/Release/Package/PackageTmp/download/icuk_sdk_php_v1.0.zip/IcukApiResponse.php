<?php

/**
 * ICUK API response.
 * @property $errorMessage
 * @property $errorStatusCode
 * @property $response
 * @property $success
 */
class IcukApiResponse {

	/**
	 * Error message.
	 */
	public $errorMessage;
	
	/**
	 * Error type.
	 */
	public $errorType;

	/** 
	 * Status code.
	 */
	public $statusCode;

	/**
	 * Response JSON
	 */
	public $response;

	/**
	 * Response JSON
	 */
	public $success;
	
}
?>