﻿using IcukApiCSharpSdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BroadbandChecker {

    /// <summary>
    /// Example page which sends request using the C# SDK to check for broadband availability.
    /// </summary>
    public partial class index : System.Web.UI.Page {

        /// <summary>
        /// Event which is triggered when the page loads.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">Event arguments.</param>
        protected void Page_Load(object sender, EventArgs e) {

            // Handle page actions
            string pageAction = HttpContext.Current.Request.QueryString["action"];
            if (pageAction == "broadband-availability-cli") {
                string cli = (String)HttpContext.Current.Request.Params.Get("cli");
                Response.Write(ApiRequest("/broadband/availability/" + cli));  
                return;
            }
            else if (pageAction == "address-search") {
                string postCode = (String)HttpContext.Current.Request.Params.Get("postcode");
                Response.Write(ApiRequest("/broadband/address_search/" + postCode));  
            }
            else if (pageAction == "broadband-availability-exact") {
                string exactAddress = Request.Form.GetValues("address").FirstOrDefault<string>();
                Response.Write(ApiRequest("/broadband/availability", "POST", exactAddress));
            }
            else {
                Main();
            }
        }

        /// <summary>
        /// Sends API request using the C# SDK.
        /// </summary>
        /// <param name="apiMethod">API method.</param>
        /// <param name="method">HTTP method.</param>
        /// <param name="body">POST data.</param>
        /// <returns>API response.</returns>
        public string ApiRequest(string apiMethod, string method="GET", string body = null) {

            String result = String.Empty;

            IcukApiClient api = new IcukApiClient {
                Username = "<username>",
                Key = "<key>",
                Encryption = "SHA-512"
            };

            IcukApiRequest req = new IcukApiRequest {
                Url = apiMethod,
                Method = method,
            };

            if (body != null) {
                req.Body = body;
            }

            IcukApiResponse res = api.Send(req);
            if (res.Success) {
                result = res.Response;
            }
            else {
                HttpContext.Current.Response.StatusCode = res.StatusCode;
                result = res.ErrorMessage;
            }
                               
            return result;

        }  

        /// <summary>
        /// Gets the broadband checker form.
        /// </summary>
        /// <returns>HTML form which sends broadband checker requests to the API.</returns>
        private string GetBroadbandCheckerForm() {
            
            HttpRequest request = HttpContext.Current.Request;

            string checkerType = request.QueryString["checker_type"] == null ? "" : request.QueryString["checker_type"];
            string cli = request.QueryString["cli"] == null ? "" : request.QueryString["cli"];
            string postcode = request.QueryString["postcode"] == null ? "" : request.QueryString["postcode"];

            if (String.IsNullOrWhiteSpace(checkerType) || (!checkerType.Equals("cli") && !checkerType.Equals("postcode")))
                checkerType = "cli";   

            StringBuilder html = new StringBuilder();
    
            html.Append(@"		
        <form class='content-form' method='get' action='' id='form1' role='form' name='form1'>
			
			<p>
				Welcome to the Broadband Availability checker. This will provide a provisional check of your ability to receive Broadband 
				services. Simply enter your phone number or post code to start a search. A phone number check will produce the most 
				accurate result.
			</p>
			
			<br />
			
			<table class='content-table table-curved' style='width:50%; margin:0 auto;'>
			
				<tr>            
					<th width='35%'>
						<label for='type_phone'>Phone Number</label>
					</th>
					<td width='5%' class='centered'>
						<input id='type_phone' name='action' onfocus='changeInputSelection(""cli"")' value='telephone_checker' type='radio'" + (checkerType.Equals("cli") ? "checked='checked' />" : "/>") + @"
					</td>
					<td>
						<input class='form-control text-input' onfocus='changeCheckerRadio(""cli"")' id='cliInput' name='CLI' size='18' type='text' value='" + (checkerType.Equals("cli") ? cli : "") + @"' />
					</td>
				</tr>
				
				<tr>
					<th><label for='type_postcode'>Postcode</label></th>
					<td><input id='type_postcode' name='action' onfocus='changeInputSelection(""postcode"")' value='postcode_checker' type='radio'" + (checkerType.Equals("postcode") ? "checked='checked' />" : "/>") + @"</td>
					<td><input class='form-control text-input' onfocus='changeCheckerRadio(""postcode"")' id='postcodeInput' name='postcode' size='18' type='text' value='" + (checkerType.Equals("postcode") ? postcode : "") + @"' /></td>
				</tr>

			</table>
			
			<br />

			<div style='max-width:400px; margin:0 auto;'>            
				<p class='centered'>
				<button type='button' id='searchButton' class='btn btn-success' onclick='checkRequest();'><span class='glyphicon glyphicon-search'></span> Search</button>
				</p>
			</div>
        
        </form>");

            return html.ToString();
        }

        /// <summary>
        /// Main webpage template.
        /// </summary>
        private void Main() {

            StringBuilder html = new StringBuilder();

            // Head
            html.Append(@"
<!DOCTYPE html>
<html lang='en'>
<head>	
	<title>Broadband Availability Checker</title>
	<meta charset='utf-8'>
	<meta name='viewport' content='width=device-width, initial-scale=1.0'>	
	<meta name='description' content='The broadband checker allowing you to search for availability and predicted speeds for ADSL, FTTC, and FTTP services.'>
	<meta name='keywords' content='broadband, checker, availability, adsl, fttc, fttp, bt wholesale, cable ane wireless, predicted speeds'>
	<meta http-equiv='content-type' content='text/html; charset=iso-8859-1'>	
	<link href='/css/bootstrap.css' rel='stylesheet' />
	<link href='/css/style.css' rel='stylesheet' />
	<script src='/javascript/jquery.js' type='text/javascript'></script>
	<script src='/javascript/bootstrap.js' type='text/javascript'></script>
	<script src='/javascript/broadband_availability.js' type='text/javascript'></script>
</head>");

            // Header
            html.Append(@"
<body>

	<div class='header'>
		<div class='header-center'>
			<div class='header-title'>
				<h1>Broadband Checker</h1>
				<p>Confirm products and speeds available</p>
			</div>
			<div class='header-signup pull-right'>
				<a href='/signup.aspx' class='btn btn-mini btn-success btn-signup btn-custom-lighten' type='button'>SIGNUP ONLINE</a>
			</div>						
		</div>
  	</div>");

            // Content
            html.Append(@"
 <div class='content'>	
    
        <div class='content-header'>
			<h1>Availability &amp; Estimated Speed</h1>
			<h2>Use our checker tool to confirm the availability of broadband products to your line</h2>
        </div>");
	
            // Broadband checker form
            html.Append(GetBroadbandCheckerForm());

            html.Append(@"

        <div id='errorText' style='display:none'></div>

        <div id='addressDiv' style='display:none'></div>

        <div id='results' style='display:none'>
        
            <h3 id='resultsTitle' class='centered'></h3>
        
            <table class='content-table table-curved' style='width:65%; margin:0 auto;'>
        
        	    <thead>
                <tr>
				    <th width='50%'>Product</th>
				    <th width='25%'>Availability</th>
				    <th width='25%'>Download Speed<br />(Upload Speed)</th>
                </tr>
                </thead>
            
                <tr>
				    <td>20CN ADSL Max</td>
				    <td id='adslMaxAvail' class='centered'></td>
				    <td id='adslMaxSpeed' class='centered'></td>
                </tr>
                <tr>
				    <td>21CN ADSL 2+</td>
				    <td id='adsl2plusAvail' class='centered'></td>
				    <td id='adsl2plusSpeed' class='centered'></td>
                </tr>
                <tr id='annexMTr'>
				    <td>21CN Annex M</td>
				    <td id='adsl2plusAnnexMAvail' class='centered'></td>
				    <td id='adsl2plusAnnexMSpeed' class='centered'></td>
                </tr>		
                <tr>
				    <td>Cable & Wireless LLU ADSL 2+</td>
				    <td id='lluUnlimitedAvail' class='centered'></td>
				    <td id='lluUnlimitedSpeed' class='centered'></td>
                </tr>
                <tr>
				    <td>Fibre to the Cabinet (FTTC)</td>
				    <td id='fttcAvail' class='centered'></td>
				    <td id='fttcSpeed' class='centered'></td>
                </tr>		
                <tr>
				    <td>Fibre to the Premises (FTTP)</td>
				    <td id='fttpAvail' class='centered'></td>
				    <td id='fttpSpeed' class='centered'></td>
                </tr>			
            </table>
        
            <br />

            <h3 class='centered'>Exchange Information</h3>

            <table class='content-table table-curved' style='width:50%; margin:0 auto;' id='statusTbl' >
                <tr>
				    <th width='40%'>Status</th>
				    <td id='status'>&nbsp;</td>
                </tr>
                <tr>
				    <th>Message</th>
				    <td id='message'></td>
                </tr>
            
                <tr>
				    <th width='40%'>Exchange Code</th>
				    <td id='exCode'></td>
                </tr>
                <tr>
				    <th>Exchange Name</th>
				    <td id='exName'></td>
                </tr>
            </table>
        </div>		
    </div>");

            html.Append(@"
    <div class='modal fade' id='console-dialog' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true' style='overflow-y:auto'>
      <div class='modal-dialog'>
        <div class='modal-content'>
          <div class='modal-header'>
            <button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
            <h4 class='modal-title'></h4>
          </div>
          <div class='modal-body'></div>
          <div class='modal-footer'>
            <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
          </div>
        </div>
      </div>
</div>");      

            html.Append(@"
</body>
</html>");

            HttpContext.Current.Response.Write(html.ToString());
        }
    }
}