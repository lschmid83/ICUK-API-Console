package com.icuk.javasdk;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.net.ssl.HttpsURLConnection;

/**
 * ICUK API client.
 */
public class IcukApiClient {

	public String Username;
	public String Key;
	public String Encryption;
	
	/**
	 * Sends the request.
	 * @param request IcukApiRequest object.
	 * @return IcukApiResponse object containing API response.
	 */
	public IcukApiResponse send(IcukApiRequest request)
	{
		IcukApiResponse response = new IcukApiResponse();
		HttpsURLConnection conn = null;
		OutputStream os = null;
		InputStream is = null;
		try
		{
			URL url = new URL(request.Url);
			conn = (HttpsURLConnection) url.openConnection();
			conn.setRequestMethod(request.Method);
			conn.setRequestProperty("Content-Type", "application/json");
			
			String hash;
			
			if(Encryption == null) {
				Encryption = "SHA-512";
			}
			
			String method = url.getPath();
			hash = hash(method + Key, Encryption);
					
			conn.setRequestProperty("User", Username);
			conn.setRequestProperty("Hash", hash);
			conn.setRequestProperty("Encryption", Encryption);
			
			if(request.MessageBody != null)	{
				
				conn.setDoOutput(true);
				request.MessageBody = "=" + request.MessageBody;
				os = conn.getOutputStream();
				os.write(request.MessageBody.getBytes());
				os.flush();
			}
			
			is = new BufferedInputStream(conn.getInputStream());
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
	 
			StringBuilder result = new StringBuilder();
			String output;
			while ((output = br.readLine()) != null) {
				result.append(output);
			}
			
		    response.Response = result.toString();
		    response.Success = true;
		}
		catch(Exception ex) {
			response.ErrorMessage = ex.toString();
			response.Success = false;
		}
		finally {	
			
			if (os != null) {
		        try {
		            os.close();
		        } catch (IOException e) {
		        }
		    }
			
			if (is != null) {
		        try {
		            is.close();
		        } catch (IOException e) {
		        }
		    }
						
			if(conn != null) {
				conn.disconnect();	
			}
		}

		return response;
	}
		
	/**
	 * Creates a hash of the plain text using the encryption method.
	 * @param plainText
	 * @param encryptionMethod
	 * @return
	 * @throws NoSuchAlgorithmException
	 */
	public String hash(String plainText, String encryptionMethod) throws NoSuchAlgorithmException {
		
		 MessageDigest md;
		
		 md= MessageDigest.getInstance("SHA-512");
		
		 md.update(plainText.getBytes());
         byte[] mb = md.digest();
         String out = "";
         for (int i = 0; i < mb.length; i++) {
             byte temp = mb[i];
             String s = Integer.toHexString(new Byte(temp));
             while (s.length() < 2) {
                 s = "0" + s;
             }
             s = s.substring(s.length() - 2);
             out += s;
         }

         return out;
	}
	
}
