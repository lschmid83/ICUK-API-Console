package com.icuk.javasdk;

/**
 * ICUK API response.
 */
public class IcukApiResponse {

	public String ErrorMessage;
	public String Response;
	public boolean Success;
	
}
