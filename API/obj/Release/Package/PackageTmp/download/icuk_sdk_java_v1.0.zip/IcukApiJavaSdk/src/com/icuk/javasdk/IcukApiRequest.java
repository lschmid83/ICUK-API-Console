package com.icuk.javasdk;

/**
 * ICUK API request.
 */
public class IcukApiRequest {

	public String Url;
	public String Method;
	public String MessageBody;

}
